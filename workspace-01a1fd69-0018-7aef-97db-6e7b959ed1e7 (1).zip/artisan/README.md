# Artisan Café

A responsive Copenhagen café concept using Vite and Three.js, with a palette centred on #6F4E37.

## Run

```sh
npm install
npm run dev -- --port 3000
```

## Build

```sh
npm run build
npm run preview -- --port 3000
```

## Café features

- Original procedural 3D coffee-cup hero with drag, pointer and scroll interaction
- Keyboard-accessible coffee, breakfast, lunch and bakery menu tabs
- 26 sample menu items, Danish kroner pricing, dietary labels and serving times
- Table reservation preview for 1 to 6 guests, date validation, and sample time slots adjusted for Copenhagen time and weekend hours
- Opening hours, kitchen hours, sample location and external neighbourhood map link
- Contact message preview and accessible visitor FAQs
- Privacy Policy and Terms dialogs
- Mobile navigation, responsive layouts and reduced-motion support

## Demo notice

This is a fictional café, not a live reservation system. The address, contact details, prices and hours are illustrative. Reservation and contact forms only render previews in the browser. No data is sent, persisted, or emailed. No table is actually booked and no payment is collected. The sample .example email and phone number are not monitored. A real café launch requires real business details and a booking/contact backend.

## Assets

Cups are built from procedural geometry and canvas textures. No AI-generated imagery is used. Playfair Display and DM Sans are served locally. Coffee photographs are from Unsplash:

- https://images.unsplash.com/photo-1447933601403-0c6688de566e
- https://images.unsplash.com/photo-1442512595331-e89e73853f31

## Browser testing

Verified menu tab content, reservation and contact previews, privacy dialog, a functioning WebGL canvas, and no horizontal overflow at desktop and mobile sizes.
